/*
* mail prof : nader.jelassi@isima.fr
* objet mail : (séance lundi)TP N°X
*/

class Hello {
	public static void main(String[] args) {
		System.out.println("Hello World !");
	}
}
class Main {
	public static void main(String[] args) {
		Banque b = new Banque();
		System.out.println(b.proprio(2));
		b.
	}
}
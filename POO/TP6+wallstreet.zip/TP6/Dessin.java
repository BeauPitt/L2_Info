import java.awt.*;
import java.io.*;
import java.awt.image.BufferedImage ;

class Dessin extends Canvas {

	public void paint(Graphics g) {
		g.setColor(Color.blue);
		g.drawRect(0, 0, 20, 20);
		// echiquier 8x8
		g.fillRect(0,0,0,0);
		for (int i = 0; i < 8; i++) {
			g.drawLine(i*8,0,i*8,8*8);
		}
		for (int i = 0; i < 8; i++) {
			g.drawLine(i*8,0,8*8,i*8);
		}

		File f = new File("psg.jpg");
		BufferedImage bi = null;

		try {
			bi = javax.imageio.ImageIO.read(f);
		} catch (IOException e) {
			e.printStackTrace();
		}

		g.drawImage(bi,0,0,null);

	}

}
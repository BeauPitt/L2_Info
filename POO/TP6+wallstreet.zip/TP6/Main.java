import java.awt.*;

public class Main {
	
	public static void main(String[] args) {
	 	//TP6Frame2 fenetre = new TP6Frame2("");
		//TP6Frame fenetre2 = new TP6Frame();
		TPFrame fenetre = new TPFrame();
	}
}

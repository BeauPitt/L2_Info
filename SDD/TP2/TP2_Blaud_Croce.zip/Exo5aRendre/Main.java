/*
* à rendre le 26 avril avant minuit - chapelle.quentin@gmail.com
* TP NOTÉ - Lylian BLAUD / Loris CROCE
*/

class Main {

	public static void main(String[] args) {
		Element elem = new Element('-');
		System.out.println(elem);
		Element elem2 = new Element(3);
		System.out.println(elem2);

		Polynome pol = new Polynome("5+4");
		System.out.println(pol);

	}

}

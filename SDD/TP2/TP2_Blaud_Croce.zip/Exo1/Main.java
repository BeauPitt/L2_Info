class Main {
	public static void main(String[] args) {
		
		int[] tab = new int[5];
		Pile pile = new Pile();
	}
}
class Arbre {

	// attribut
	private Noeud noeud;

	// constructeur
	public Arbre(Noeud n) {
		noeud = n;
	}

	public int Calcul() {
		int resultat;

		return resultat;

	}
}
